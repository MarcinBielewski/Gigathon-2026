import turtle
import random
import time


#hiper pauza
def pauza(milisekundy, coZrobic):
    screen.update()
    screen.ontimer(coZrobic, milisekundy)

def KrokLewo():
    global aktywna
    if not aktywna: return
    global kroki
    global Glej
    newX = player.xcor()-KROK
    kroki += 1
    Glej -= 0.5
    print("\rGlej:", Glej,"  Kroki:",kroki, end="", flush=True)
    if newX<-249:
        player.hideturtle()
        player.setx(249)
        player.showturtle()
    else:
        pauza(30,lambda:player.setx(newX))
        


def KrokPrawo():
    global aktywna
    if not aktywna: return
    global kroki
    global Glej
    newX = player.xcor()+KROK
    kroki +=1
    Glej -=0.5
    print("\rGlej:", Glej,"  Kroki:",kroki, end="", flush=True)
    if newX>249:
        player.hideturtle()
        player.setx(-249)
        player.showturtle()
    else:
        pauza(30,lambda:player.setx(newX))


def KrokDol():
    global aktywna
    if not aktywna: return
    global kroki
    global Glej
    newY = player.ycor()-KROK
    kroki += 1
    Glej -=0.5
    print("\rGlej:", Glej,"  Kroki:",kroki, end="", flush=True)
    if newY<-249:
        player.hideturtle()
        player.sety(249)
        player.showturtle()
    else:
        pauza(30,lambda:player.sety(newY))


def KrokGora():
    global aktywna
    if not aktywna: return
    global kroki
    global Glej
    newY = player.ycor()+KROK
    kroki +=1
    Glej -=0.5
    print("\rGlej:", Glej,"  Kroki:",kroki, end="", flush=True)
    if newY>249:
        player.hideturtle()
        player.sety(-249)
        player.showturtle() #zależność tp na drugi koniec 
    else:
        pauza(30,lambda:player.sety(newY))

  


def Atakwody(k, ile_krokow=0):
    global Glej
    global kroki
    global aktywna #zamraża ekran
    if not aktywna:return
    if k.isvisible() and k.distance(player) < 20:
        if k.shape() == "Aobiekt.gif":
            Glej -= 50
            print("\rGlej:", Glej,"  Kroki:",kroki, end="", flush=True)
        else:
            Glej += 30
            print("\rGlej:", Glej,"  Kroki:",kroki, end="", flush=True)
       
        k.hideturtle()
        pauza(5000, lambda: ResetKlona(k))
        return
    if ile_krokow <= 0:
        
        if k.shape() == "obiekt.gif":
            if random.randint(1, 50) == 2:
                k.shape("Aobiekt.gif")
                Atakwody(k, random.randint(50, 200))
                return
            else:
                pauza(50, lambda: Atakwody(k, 0))
                return
        
        if random.randint(1, 4) == 2:
            k.shape("Aobiekt.gif")
            Atakwody(k, random.randint(50, 200))
        else:
            k.shape("obiekt.gif")
            Atakwody(k, 0) 
        return

    kat = k.towards(player.pos()) #ruch
    k.setheading(kat)
    k.forward(0.8)
   
    screen.update()
    pauza(10, lambda: Atakwody(k, ile_krokow - 1))

def ResetKlona(k):
    k.goto(random.randint(-240, 240), random.randint(-240, 240))
    k.shape("obiekt.gif") 
    k.showturtle()
    Atakwody(k)

def winner():
    global aktywna #zamraża ekran
    if not aktywna:return
    screen.update()
    if Glej<=0:
        print("\nPRZEGRAŁEŚ!")
        aktywna=False
        pauza (5000,lambda:screen.bye())
    if player.distance(end) < 30:
        print("\nWYGRAŁEŚ!")
        aktywna=False
        pauza (5000,lambda:screen.bye())
    screen.ontimer(winner, 100)

###################################################################################################################################################################

#powitanie użytkownika i krótki poradnik
print("_______________________________________________________________________________________________________________\n\n")
print("WITAJ UŻYTKOWNIKU W GRZE GLEODE!\n")
print("\n")
time.sleep(1)
print("________________________________________________________________________________________________________________")
print("Potrzebujemy od Ciebie informacji aby uratować zmodyfikowany organizm o podobnej budowie co ludzkie oko!\n")
time.sleep(1)
print("Zadanie dla Ciebie jest proste musisz wypełnić dane misji i spróbować odszukać reaktywny słoik.\n")
time.sleep(1)
print("Pamiętaj jednak, że cząsteczki wody, które znajdziesz podczas podróży mogą być zarówno zabójcze jak i zbawienne.\n")
time.sleep(1)
print("POWODZENIA!")
print("________________________________________________________________________________________________________________\n")

print("DANE MISJI:\n\n")
trudno=input("Podaj trudność misji (1-łatwy, 2-średni 3-trudny):\n")
try:
    if trudno=="1":
        KROK=3
        iloscWody=5
        print("wybrano poziom łatwy \n")
    elif trudno=="2":
        KROK=2
        iloscWody=8
        print("wybrano poziom średni \n")
    elif trudno=="3":
        KROK=1
        iloscWody=20
        print("wybrano poziom trudny \n")
    else:
        raise ValueError
except ValueError: 
    KROK=3
    iloscWody=5
    print("niewłaściwa wartość! Zostaje ustawiony poziom łatwy.")

time.sleep(1)
print("\n")
print("Podaj swoje położenie na mapie: \n")
try:
    pol1=int(input("Podaj pierwszą współrzędną(wartość od -250 do 250)\n"))
    if -250<=pol1<=250:
        startx=pol1
        print("ustawiono współżędną X na: ", startx, "\n")
    else:
        raise ValueError
except ValueError:
    startx=random.randint(-240, 240)
    print("Nieprawidłowa wartość(Współżędna X została wylosowana.) \n")
    print("współżędna x wynosi:", startx)


time.sleep(1)
print("\n")
try:
    pol2=int(input("Podaj drugą współrzędną(wartość od -250 do 250)\n"))
    if -250<=pol2<=250:
        starty=pol2
        print("ustawiono współżędną y na: ", starty, "\n")
    else:
        raise ValueError
except ValueError:       
    starty=random.randint(-240, 240)
    print("Nieprawidłowa wartość(Współżędna Y zostałą wylosowana.) \n")
    print("współżędna y wynosi:", starty)


###################################################################################################################################################################
print("\n\nDziennik gry:")


kroki=0

Glej=800

aktywna=True



#inicjalizacja okna
screen = turtle.Screen()
screen.tracer(0)
screen.setup(width=500, height=500)


screen.addshape("tlo.gif") #definiowanie odpowiednich plikow z folderu
screen.addshape("player.gif")
screen.addshape("Aobiekt.gif")
screen.addshape("obiekt.gif")
screen.addshape("end.gif")
#obiekty ktore beda wyswiellane
screen.bgpic("tlo.gif") #tlo

player = turtle.Turtle() #nasz gracz
player.shape("player.gif")
player.penup()
player.sety(starty)
player.setx(startx)
###################################################################################################################################################################
KLONY = []
for i in range(iloscWody):
    klon=turtle.Turtle() #tworzenie klona w pętli
    klon.shape("obiekt.gif")
    klon.penup()
    klon.setx(random.randint(-240, 240))
    klon.sety(random.randint(-240, 240))
    KLONY.append(klon) #dodanie klona do listy
    Atakwody(klon)
###################################################################################################################################################################

end = turtle.Turtle()
end.shape("end.gif")
end.penup()
end.setx(random.randint(-240,240))
end.sety(random.randint(-240,240))

winner()







###################################################################################################################################################################


screen.listen()
screen.onkeypress(KrokGora, "Up")
screen.onkeypress(KrokDol, "Down")
screen.onkeypress(KrokLewo, "Left")
screen.onkeypress(KrokPrawo, "Right")

screen.mainloop()